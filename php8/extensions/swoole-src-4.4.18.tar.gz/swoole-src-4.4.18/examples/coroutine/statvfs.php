<?php
go(function() {
	var_dump(co::statvfs('/'));
});
