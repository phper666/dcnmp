<?php
function callback_function(swoole_process $worker)
{
    //echo "Worker: start. PID=".$worker->pid."\n";
    //recv data from master
    while(true)
    {
        $recv = $worker->pop();
        echo "From Master: $recv\n";
    }

    sleep(2);
    $worker->exit(0);
}

$process = new swoole_process('callback_function', false, false);
$process->useQueue(ftok(__FILE__, 1), 2 | swoole_process::IPC_NOWAIT);

$send_bytes = 0;
foreach(range(1, 10) as $i)
{
    $data = str_repeat('A',      /n5{
    $d>push("hello woi]talarm\n";T);

$send_+=k('N', strlen([$pid];
    $process-a)) . $dataster:
$send_bytes$g);    $dwhil;0);
}

$g);   ; $i++)
{
);    $d;
    $procker->pop()ster:
$send_+=
{
);   $dat{
    e);
={;T);

$send}, ter:=ster:
$sendtalarret);
var_dump($proker#s->useQp($ret);
