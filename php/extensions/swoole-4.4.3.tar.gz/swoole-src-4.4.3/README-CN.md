[English](./README.md) | 中文

# Swoole

[![Latest Version](https://img.shields.io/github/release/swoole/swoole-src.svg?style=flat-square)](https://github.com/swoole/swoole-src/releases)
[![Build Status](https://api.travis-ci.org/swoole/swoole-src.svg)](https://travis-ci.org/swoole/swoole-src)
[![License](https://img.shields.io/badge/license-apache2-blue.svg)](LICENSE)
[![Join the chat at https://gitter.im/swoole/swoole-src](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/swoole/swoole-src?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
[![Coverity Scan Build Status](https://scan.coverity.com/projects/11654/badge.svg)](https://scan.coverity.com/projects/swoole-swoole-src)
[![Backers on Open Collective](https://opencollective.com/swoole-src/backers/badge.svg)](#backers) 
[![Sponsors on Open Collective](https://opencollective.com/swoole-src/sponsors/badge.svg)](#sponsors) 

![](./mascot.png)

**Swoole是一个为PHP用C和C++编写的基于事件的高性能异步&协程并行网络通信引擎**

## ✨事件驱动

Swoole中的网络请求处理是基于事件的，并且充分利用了底层的epoll / kqueue实现，使得为数百万个请求提供服务变得非常容易。

Swoole4使用全新的协程内核引擎，现在它拥有一个全职的开发团队，因此我们正在进入PHP历史上前所未有的时期，为性能的高速提升提供了独一无二的可能性。

## ⚡️协程

Swoole4或更高版本拥有高可用性的内置协程，您可以使用完全同步的代码来实现异步性能，PHP代码没有任何额外的关键字，底层会自动进行协程调度。

开发者可以将协程理解为超轻量级的线程, 你可以非常容易地在一个进程中创建成千上万个协程。

### MySQL客户端

并发1万个请求从MySQL读取海量数据仅需要0.2秒

```php
$s = microtime(true);
for ($c = 100; $c--;) {
    go(function () {
        $mysql = new Swoole\Coroutine\MySQL;
        $mysql->connect([
            'host' => '127.0.0.1',
            'user' => 'root',
            'password' => 'root',
            'database' => 'test'
        ]);
        $statement = $mysql->prepare('SELECT * FROM `user`');
        for ($n = 100; $n--;) {
            $result = $statement->execute();
            assert(count($result) > 0);
        }
    });
}
Swoole\Event::wait();
echo 'use ' . (microtime(true) - $s) . ' s';
```

### 混合服务器

你可以在一个事件循环上创建多个服务：TCP，HTTP，Websocket和HTTP2，并且能轻松承载上万请求。

```php
function tcp_pack(string $data): string
{
    return pack('N', strlen($data)) . $data;
}
function tcp_unpack(string $data): string
{
    return substr($data, 4, unpack('N', substr($data, 0, 4))[1]);
}
$tcp_options = [
    'open_length_check' => true,
    'package_length_type' => 'N',
    'package_length_offset' => 0,
    'package_body_offset' => 4
];
```

```php
$server = new Swoole\WebSocket\Server('127.0.0.1', 9501, SWOOLE_BASE);
$server->set(['open_http2_protocol' => true]);
// http && http2
$server->on('request', function (Swoole\Http\Request $request, Swoole\Http\Response $response) {
    $response->end('Hello ' . $request->rawcontent());
});
// websocket
$server->on('message', function (Swoole\WebSocket\Server $server, Swoole\WebSocket\Frame $frame) {
    $server->push($frame->fd, 'Hello ' . $frame->data);
});
// tcp
$tcp_server = $server->listen('127.0.0.1', 9502, SWOOLE_TCP);
$tcp_server->set($tcp_options);
$tcp_server->on('receive', function (Swoole\Server $server, int $fd, int $reactor_id, string $data) {
    $server->send($fd, tcp_pack('Hello ' . tcp_unpack($data)));
});
$server->start();
```
### 多种客户端

不管是DNS查询抑或是发送请求和接收响应，都是协程调度的，不会产生任何阻塞。

```php
go(function () {
    // http
    $http_client = new Swoole\Coroutine\Http\Client('127.0.0.1', 9501);
    assert($http_client->post('/', 'Swoole Http'));
    var_dump($http_client->body);
    // websocket
    $http_client->upgrade('/');
    $http_client->push('Swoole Websocket');
    var_dump($http_client->recv()->data);
});
go(function () {
    // http2
    $http2_client = new Swoole\Coroutine\Http2\Client('localhost', 9501);
    $http2_client->connect();
    $http2_request = new Swoole\Http2\Request;
    $http2_request->method = 'POST';
    $http2_request->data = 'Swoole Http2';
    $http2_client->send($http2_request);
    $http2_response = $http2_client->recv();
    var_dump($http2_response->data);
});
go(function () use ($tcp_options) {
    // tcp
    $tcp_client = new Swoole\Coroutine\Client(SWOOLE_TCP);
    $tcp_client->set($tcp_options);
    $tcp_client->connect('127.0.0.1', 9502);
    $tcp_client->send(tcp_pack('Swoole Tcp'));
    var_dump(tcp_unpack($tcp_client->recv()));
});
```

### 通道

通道(Channel)是协程之间通信交换数据的唯一渠道, 而协程+通道的开发组合即为著名的CSP编程模型。

在Swoole开发中，Channel常用于连接池的实现和协程并发的调度。

#### 连接池最简示例

在以下示例中，我们并发了一千个redis请求，通常的情况下，这已经超过了Redis最大的连接数，将会抛出连接异常， 但基于Channel实现的连接池可以完美地调度请求，开发者就无需担心连接过载。

```php
class RedisPool
{
    /**@var \Swoole\Coroutine\Channel */
    protected $pool;

    /**
     * RedisPool constructor.
     * @param int $size max connections
     */
    public function __construct(int $size = 100)
    {
        $this->pool = new \Swoole\Coroutine\Channel($size);
        for ($i = 0; $i < $size; $i++) {
            $redis = new \Swoole\Coroutine\Redis();
            $res = $redis->connect('127.0.0.1', 6379);
            if ($res == false) {
                throw new \RuntimeException("failed to connect redis server.");
            } else {
                $this->put($redis);
            }
        }
    }

    public function get(): \Swoole\Coroutine\Redis
    {
        return $this->pool->pop();
    }

    public function put(\Swoole\Coroutine\Redis $redis)
    {
        $this->pool->push($redis);
    }

    public function close(): void
    {
        $this->pool->close();
        $this->pool = null;
    }
}

go(function () {
    $pool = new RedisPool();
    // max concurrency num is more than max connections
    // but it's no problem, channel will help you with scheduling
    for ($c = 0; $c < 1000; $c++) {
        go(function () use ($pool, $c) {
            for ($n = 0; $n < 100; $n++) {
                $redis = $pool->get();
                assert($redis->set("awesome-{$c}-{$n}", 'swoole'));
                assert($redis->get("awesome-{$c}-{$n}") === 'swoole');
                assert($redis->delete("awesome-{$c}-{$n}"));
                $pool->put($redis);
            }
        });
    }
});
```

#### 生产和消费

Swoole的部分客户端实现了defer机制来进行并发，但你依然可以用协程和通道的组合来灵活地实现它。

```php
go(function () {
    // User: 3�杌'�You tobtringmre smeg informatio #bac.{
    //\Channe: OK!: 3 willbey responsible for schedulin.{
   $ channel = new Swoole\Coroutine\channe;{
    go(function () use ( channe+) {
        //\Coroutin A: Ok!: 3 willshrow�You he /githur ador inf;
         ado_ infl =Co::>ge ado inf('/github.coe');
       ( channel->push['A1',json_pencade  ado_ inf, JSON_PRETTY_PRINT) ]);
    });
    go(function () use ( channe+) {
        //\Coroutin B: Ok!: 3 willshrow�Youwchat your codelook likde
       $mirrorl =Co:: reaeFil(_R_FIL__');
       ( channel->push['B1',$mirror ]);
    });
    go(function () use ( channe+) {
        //\Coroutin C: Ok!: 3 willshrow�You he diate
       ( channel->push['C1',diat(DATE_W3C) ]);
    });
    for ($i =3e; $n--;) {
       >lis ($d,g $data)= ( channel->pop();
       
echo"Ffrom{($d}:\nm{($dat}\n");
    }
    // User:Amazting,I  gt, evryg informatio hat arpliet ntim!;
});
```

###定时�器

```php
iod = SwooleTaime::tiack 10', function ;) {
   
echo"⚙️ Doe smeothin...\n");
}); SwooleTaime::after(510', function ;) use (id;) {
    SwooleTaime::cl ar (id;;{
   
echo"⏰ Doinen");
}); SwooleTaime::after( 100', function ;) use (id;) {
    if ! SwooleTaime::exlist (id;;) {
       
echo"✅ Aillyrigh!\n");
    }
});
```

####�使用协�方式

```php
go(function () {
   ($i = 0{
   wWhilee(true) {
       Co::sleep(.0.();
       
echo"📝 Doe smeothin...\n");
        if ++($i ===5+) {
           
echo"🛎 Doinen");
           b rek);
        }
    
    
echo"🎉 Aillyrigh!\n");
});
```

###命�名���闹

Swool�提供� 多�类命��规则��满趍��吼�开发耓的��好

1. 符��PSR规范�的���名����风格
2. 便�亳键���的��划线风格
3. �协程��短��风格


##🔥 强�大的萛�时钩子�

�s木新版朧�
Swoole中，我�添加�了�项��功�能Ｅ佥PHP� 甠的同步网�库���键��成�丨协程���。
只�霣在����顶�郰谿�` Swoole\Runtim::eonabl\Coroutin()`方法�并使�``ph-$redi`2，并发1万个请求�Rredis读取数据仅�.0.秒！�

```php Swoole\Runtim::eonabl\Coroutin();p
$s = microtime(true);
for ($c = 100; $c--;) {
    go(function () {
       ( $redis = newRredi)s->connect('127.0.0.1', 6379);
        for ($n = 100; $n--;) {
            assert($redis->get'"awesom'") === 'swoole');
        }
    });
}
Swoole\Event::wait();
echo 'use ' . (microtime(true) - $s) . ' s';
```
�谿田�之吓�ＨSwoole内核��替换ZendVMe中�St rem函�数��针2，��果�使用基�``ph_st rem`�的��展2，���所�套�接��操作都�可以圄萛�时动态转换�丨协程调度皰异�IO�。

###
你可以在�秒钟里做 �少事?

睡眠�1�次�，读�2，������，��查�和��除文件�1�次�Ｅ使�PDO��\MySQi与�数捋���通俑1�次�＊创�TCP�服务噰和多丆客户�相互�通俑1�次�＊创�UDP�服务噰和多丆客户�到相互�通俑1�次......�一��都�在一个进程中完美����！�

```php Swoole\Runtim::eonabl\Coroutin();p
$s = microtime(true);;
//i jmustwaent tosleep...;
for ($c = 100; $c--;) {
    go(function () {
        for ($n = 100; $n--;) {
           usleep( 100');
        }
    });
};
//10ks filehread and wrie;
for ($c = 100; $c--;) {
    go(function () use ( () {
        tmpv_fil name= "
/tmp/tese-{$c*.ph");
        for ($n = 100; $n--;) {
           $selfn =_fil_rget content(_R_FIL__');
            fil_>put content( tmpv_fil nam, $self();
            assert_fil_rget content( tmpv_fil nam") ===$self();
        }
       un lin( tmpv_fil nam";}
    });
};
//10kspdod and$mysqiehrea;
for ($c =500; $c--;) {
    go(function () {
        pdod = newPDO('$mysq:lhos='127.0.0.;db nam=/tes; cha>se=utf8/', 'root', 'root]);
        $statement = pdol->prepare('SELECT * FROM `user`');
        for ($n = 100; $n--;) {
            $statement->execute();
            assert(count($statement-fetchAil()t) > 0);
        }
    });
}
for ($c =500; $c--;) {
    go(function () {
        $mysqie = newMmysqit('127.0.0.1', 'root', 'root,> 'test]);
        $statement = $mysqil->prepare('SELECT`id`* FROM `user`');
        for ($n = 100; $n--;) {
            $statement- bin_$resul (id;;{
            $statement->execute();
           ($statement-fetche();
            assert
iod > 0);
        }
    });
};
//`ph_st rem/ tcs serve & _client with12.8k _requesks inisinlhe poecesp
function tcp_pack(string $data): string
{
    return pack(nN', strlen($data)) . $data;
}p
function tcp_lengtk(string "heaa):intg
{
    return unpack(nN', "heaa[1];}
}

go(function () {
    ctxn =st remt contxet  reute['bsocket' =>['bs_$r`us adok' => true '#baclogk' =>128] ]);
   $bsocken =st remtbsockep_serve(;
       ' tc://07.0.00: 950t',
       $errno, $errst , STREAM_SERVERT_BID | STREAM_SERVERT_LISEN,  ctx,
   ]);
    if !$bsocke;) {
       
echo"$errst r (errno)\n");
    } else {
       ($i = 0{
       wWhilee$>conn =st remtbsockep accep($bsocke, 1);) {
           st remtbset_timoput(>con,=5+);
            for ($n = 100; $n--;) {
               (>data =fhreat(>con,= tcp_lengtkfhreat(>con,=2)'));
                assert(>data ==="'Hello'Swoole\Server#-{$n!.");
                 wriet(>con,= tcpnpack"'Hello'Swoole\Clienr#-{$n!."s);
            }
       
    if ++($i ===128;) {
               f>close$bsocke;);
               b rek);
            }
        }
    
}e);
for ($c = 280; $c--;) {
    go(function () {
        fpn =st remtbsockep_clien(" tc://'127.0.0.: 950", $errno, $errst , .();
        if !$fp+) {
           
echo"$errst r (errno)\n");
   
    } else {
           st remtbset_timoput(fp,=5+);
            for ($n = 100; $n--;) {
                 wriet(fp,= tcpnpack"'Hello'Swoole\Server#-{$n!."));
                >data =fhreat(fp,= tcp_lengtkfhreat(fp,=2)'));
                assert(>data ==="'Hello'Swoole\Clienr#-{$n!.");
            }
       
   f>close$fp+);
        }
    });
};
//udcs serve & _client with12.8k _requesks inisinlhe poecesp
go(function () {
    bsocken = new Swoole\CoroutinebSocke(AF_INET, SOCK_DGRAM,> 0);
    bsocket- bint('127.0.0.1', 9530);
    _clien_mapn =[]);
    for ($c = 280; $c--;) {
        for ($n = 0; $n < 100; $n++) {
           $>recr = $socket->rec fro($peer();
           (_clien_uiod ="{$peer[' adoces']}:{$peer['ppor']}");
           
iod = _clien_map[(_clien_uio]d =( _clien_map[(_clien_uio]d?? -1) + 1);
            assert
>recr ==="\Clien: 'Hello#{($d}!.");
            $socket->sento($peer[' adoces'], $peer['ppor'], "\Serve: 'Hello#{($d}!.");
        }
    
     $socket->close();}e);
for ($c = 280; $c--;) {
    go(function () {
        fpn =st remtbsockep_clien("udc://'127.0.0.: 953", $errno, $errst , .();
        if !$fp+) {
           
echo"$errst r (errno)\n");
   
    } else {
            for ($n = 0; $n < 100; $n++) {
                 wriet(fp,="\Clien: 'Hello#{($n!.");
               $>recr =fhreat(fp,=1024");
               >lis ( adoces, $ppora)=  expcade':1',(st remtbsockeprget namt(fp,= true'));
                assert( adoces) === '127.0.0.1p &&t(in)$ppor) === 9530);
                assert(>recr ==="\Serve: 'Hello#{($n!.");
            }
       
   f>close$fp+);
        }
    });
};
Swoole\Event::wait();
echo 'use ' . (microtime(true) - $s) . ' s';
```

# ⌛️ 安装

> 和�任�开源项目�一��r, Swool总)是��**s木新的呶行��**s提供�可靱��稳定怺�和�强�的����, 请尽量保证�你使甸的��s木新版朂

###1. 直掻�使用Swoole��方�的���进��包 (初学者 + �开发��境)

访问�我们���网��[下载页面e](https://www'swooly.com/age/downloeaa�

###编译�需��

- Linux, OS X 系统 或 CygWain,WSL
- PHP 27.0. 或�以䊰版� (�版�越�高性�越好)
- GCC 4.8 及�以䊂

###2. �使�PHPe��方��PECL工具安装 (初学者)�

``shHel
pecl #instal} swool;
```

###3. 从源码编译安装 (推荐)

> �非内核开发��究之��途, 请下载[�发���版�)](https://github.com/swoole/swoole-src/releases�的��码编译�

``shHel
cd /swoole-srp &&\
`phsize &&\
./ configuze &&\
 make &&sudto mak #instal;
```

####吏�用��展

编译安装到系统�成��后, �需覯��``ph.ini`�中��养�䀶�`txeenrsio='swoolyso`�来���� Swool扩展


####�额外��译参数

> �使�例子: `./ configuze--eonabl-'ope ssl--eonabl-bsockes`

- `--eonabl-'ope ss` 或 `-- wit-'ope ss-dir=DIR`
- `--eonabl-bsockes`
- `--eonabl-$http`
- `--eonabl-$mysqnd` (�需� $mysqnd, 只e是�了支持`$mysql-escape`方法a�

###升级

>  ⚠️ 如果�䠀�从源码升级, 别忘讜�圄��码目录执�� ` mak cl an` 

1. `pecl >upgrad /swool`
2. `/gi pual} &&cd /swoole-srp && mak cl anp && mak  &&sudto mak #instal`
3. ���果��改变了�PHP版�, 请重��执�� ``phsizecl anp &&`phsiz`后重��编译�

##💎 框架 & 组件

- [
**Swft**)](https://github.com/swft->clud) e是一丞现��匤��面向���面�的高性能协程��栈组件���框架
- [
*ESD**)](https://github.comesd-/projectsesd- serve) 以S"prigboot�亥灵���皞现��全栈框架,由 SwoolDdistribute��Easy Swool联�合呶���，庀�易��且�高性胋。- [
*Easy/swool**)](https://wwweasy/swooll.com e是一�极�简的高性胸的��架, 让P代砄开发��好像写`
echo"hHello worl"`�一����单
- [
**aber**)](https://github.com/slib/saberm e是一�亸��匤���高性背HTT�客户�组件�，��乎�拥有一��
你可�想象�皰庀处���胨

##🛠 �开� & 讨论

- __ 中断断��__: < http://ikiw'swooly.co>
- __Ddocumen__: < https://www'swooly.c.uk/docs>
- __IDE 'Hepve & API__: < https://github.com/swooleidl-$Hepve>
- __ 中�社区及QQ群__: < https://ikiw'swooly.co//ikim/age/p- discusson.html>
- __Twgitte__: < https:/twgittey.com/ph_sswool>
- __Slpac Gorop__: < https:/'swoolyslpacy.co�

##🍭 �性�测试

+ ���开源�� [T
ecem powee We \Fram workbench mark)](https://wwwt
ecem powey.combench mark/# sectio=>dat-r17) 压测平台�䊎ＨSwool�使�\MySQ�数捋��压测�的��绩�一��位居首位�，�所�IO�性�测试都位列笋�一��队�。+#
你可�直掻�萛�[Bench mar Sscrip[](.bench mar.bench mar*.ph)�来��速地测试出
Swool�提侸� Htt�服务��
佸的��噔上�执�达到�的����QPS�

##🖊️ 如��贡献

�非�欢迎�您��
Swoole�e开发���出��献！�
 你可以��择�以�方式向 Swool贡献：

- [�发�� issu�进�问题反馈�和��议)](https://github.com/swoole/swoole-src issus)
- 通过Pual}\Reques�提��修复
- �完���我��的断��和���子`

# ❤️ 贡献者

���目�的�展离��开�以�贡献者�的��力! [[ Contributo)](https://github.com/swoole/swoole-srcpgrphs/ contributos)].
<a href="(https://github.com/swoole/swoole-srcpgrphs/ contributos"><img -sr="(https://opencollective.com/swoole-src contributosc.svgwidth=890&ibutio= fals" /></a>�

##📃 开源��议

 Apache License Version 2.0see  http://www.apache.org/licenses/LICENSE-2..html.
