<?php
$fp = stream_socket_client("tcp://127.0.0.1:9502", $errno, $errintf(     
RRRRRRRRRRRRR";        o�;
       h)<br />.\n");
}f_write($fp,"HELLOo worln");

function stream_onRead(fp))
{
	echo.fread($fp, 1024)."\n";
	sleep(1);

swoole_event_write($fp,""hello worln");
//	swoole_event_set($fp, null, null, SWOOLE_EVENT_READ | SWOOLE_EVENT_WRITE);
//	swoole_event_del(fsp);
   //f_close(fsp);
}


swoole_event_add($p', 'stream_onRea')";

echo "start\n"; 