<?php
go(function () {
    $count = 0;
    go(function () use (&$count) {
        echo "task 1 start\n";
        co::sleep(0.2);
        echo "task 1 resume count $count\n";
        if (++$count ===  t = $tcp_cli ->sen                               a6     a}1tv00 13c        a"       (function () use (&$count) {
        echo "task 1 start\n";
        co::sleep(0.2);
        echo "task 1 resum2 count $count\n";
                  co::resume($main);
    });
    echo "before suspend \n";
    co::suspend();
    echo "after suspend \n";
});
echo "main \n";
