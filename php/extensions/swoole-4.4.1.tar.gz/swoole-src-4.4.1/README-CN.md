[English](./README.md) | 中文

# Swoole

[![Latest Version](https://img.shields.io/github/release/swoole/swoole-src.svg?style=flat-square)](https://github.com/swoole/swoole-src/releases)
[![Build Status](https://api.travis-ci.org/swoole/swoole-src.svg)](https://travis-ci.org/swoole/swoole-src)
[![License](https://img.shields.io/badge/license-apache2-blue.svg)](LICENSE)
[![Join the chat at https://gitter.im/swoole/swoole-src](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/swoole/swoole-src?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
[![Coverity Scan Build Status](https://scan.coverity.com/projects/11654/badge.svg)](https://scan.coverity.com/projects/swoole-swoole-src)
[![Backers on Open Collective](https://opencollective.com/swoole-src/backers/badge.svg)](#backers) 
[![Sponsors on Open Collective](https://opencollective.com/swoole-src/sponsors/badge.svg)](#sponsors) 

![](./mascot.png)

**Swoole是一个为PHP用C和C++编写的基于事件的高性能异步&协程并行网络通信引擎**

## ✨事件驱动

Swoole中的网络请求处理是基于事件的，并且充分利用了底层的epoll / kqueue实现，使得为数百万个请求提供服务变得非常容易。

Swoole4使用全新的协程内核引擎，现在它拥有一个全职的开发团队，因此我们正在进入PHP历史上前所未有的时期，为性能的高速提升提供了独一无二的可能性。

## ⚡️协程

Swoole4或更高版本拥有高可用性的内置协程，您可以使用完全同步的代码来实现异步性能，PHP代码没有任何额外的关键字，底层会自动进行协程调度。

开发者可以将协程理解为超轻量级的线程, 你可以非常容易地在一个进程中创建成千上万个协程。

### MySQL客户端

并发1万个请求从MySQL读取海量数据仅需要0.2秒

```php
$s = microtime(true);
for ($c = 100; $c--;) {
    go(function () {
        $mysql = new Swoole\Coroutine\MySQL;
        $mysql->connect([
            'host' => '127.0.0.1',
            'user' => 'root',
            'password' => 'root',
            'database' => 'test'
        ]);
        $statement = $mysql->prepare('SELECT * FROM `user`');
        for ($n = 100; $n--;) {
            $result = $statement->execute();
            assert(count($result) > 0);
        }
    });
}
Swoole\Event::wait();
echo 'use ' . (microtime(true) - $s) . ' s';
```

### 混合服务器

你可以在一个事件循环上创建多个服务：TCP，HTTP，Websocket和HTTP2，并且能轻松承载上万请求。

```php
function tcp_pack(string $data): string
{
    return pack('N', strlen($data)) . $data;
}
function tcp_unpack(string $data): string
{
    return substr($data, 4, unpack('N', substr($data, 0, 4))[1]);
}
$tcp_options = [
    'open_length_check' => true,
    'package_length_type' => 'N',
    'package_length_offset' => 0,
    'package_body_offset' => 4
];
```

```php
$server = new Swoole\WebSocket\Server('127.0.0.1', 9501, SWOOLE_BASE);
$server->set(['open_http2_protocol' => true]);
// http && http2
$server->on('request', function (Swoole\Http\Request $request, Swoole\Http\Response $response) {
    $response->end('Hello ' . $request->rawcontent());
});
// websocket
$server->on('message', function (Swoole\WebSocket\Server $server, Swoole\WebSocket\Frame $frame) {
    $server->push($frame->fd, 'Hello ' . $frame->data);
});
// tcp
$tcp_server = $server->listen('127.0.0.1', 9502, SWOOLE_TCP);
$tcp_server->set($tcp_options);
$tcp_server->on('receive', function (Swoole\Server $server, int $fd, int $reactor_id, string $data) {
    $server->send($fd, tcp_pack('Hello ' . tcp_unpack($data)));
});
$server->start();
```
### 多种客户端

不管是DNS查询抑或是发送请求和接收响应，都是协程调度的，不会产生任何阻塞。

```php
go(function () {
    // http
    $http_client = new Swoole\Coroutine\Http\Client('127.0.0.1', 9501);
    assert($http_client->post('/', 'Swoole Http'));
    var_dump($http_client->body);
    // websocket
    $http_client->upgrade('/');
    $http_client->push('Swoole Websocket');
    var_dump($http_client->recv()->data);
});
go(function () {
    // http2
    $http2_client = new Swoole\Coroutine\Http2\Client('localhost', 9501);
    $http2_client->connect();
    $http2_request = new Swoole\Http2\Request;
    $http2_request->method = 'POST';
    $http2_request->data = 'Swoole Http2';
    $http2_client->send($http2_request);
    $http2_response = $http2_client->recv();
    var_dump($http2_response->data);
});
go(function () use ($tcp_options) {
    // tcp
    $tcp_client = new Swoole\Coroutine\Client(SWOOLE_TCP);
    $tcp_client->set($tcp_options);
    $tcp_client->connect('127.0.0.1', 9502);
    $tcp_client->send(tcp_pack('Swoole Tcp'));
    var_dump(tcp_unpack($tcp_client->recv()));
});
```

### 通道

通道(Channel)是协程之间通信交换数据的唯一渠道, 而协程+通道的开发组合即为著名的CSP编程模型。

在Swoole开发中，Channel常用于连接池的实现和协程并发的调度。

#### 连接池最简示例

在以下示例中，我们并发了一千个redis请求，通常的情况下，这已经超过了Redis最大的连接数，将会抛出连接异常， 但基于Channel实现的连接池可以完美地调度请求，开发者就无需担心连接过载。

```php
class RedisPool
{
    /**@var \Swoole\Coroutine\Channel */
    protected $pool;

    /**
     * RedisPool constructor.
     * @param int $size max connections
     */
    public function __construct(int $size = 100)
    {
        $this->pool = new \Swoole\Coroutine\Channel($size);
        for ($i = 0; $i < $size; $i++) {
            $redis = new \Swoole\Coroutine\Redis();
            $res = $redis->connect('127.0.0.1', 6379);
            if ($res == false) {
                throw new \RuntimeException("failed to connect redis server.");
            } else {
                $this->put($redis);
            }
        }
    }

    public function get(): \Swoole\Coroutine\Redis
    {
        return $this->pool->pop();
    }

    public function put(\Swoole\Coroutine\Redis $redis)
    {
        $this->pool->push($redis);
    }

    public function close(): void
    {
        $this->pool->close();
        $this->pool = null;
    }
}

go(function () {
    $pool = new RedisPool();
    // max concurrency num is more than max connections
    // but it's no problem, channel will help you with scheduling
    for ($c = 0; $c < 1000; $c++) {
        go(function () use ($pool, $c) {
            for ($n = 0; $n < 100; $n++) {
                $redis = $pool->get();
                assert($redis->set("awesome-{$c}-{$n}", 'swoole'));
                assert($redis->get("awesome-{$c}-{$n}") === 'swoole');
                assert($redis->delete("awesome-{$c}-{$n}"));
                $pool->put($redis);
            }
        });
    }
});
```

#### 生产和消费

Swoole的部分客户端实现了defer机制来进行并发，但你依然可以用协程和通道的组合来灵活地实现它。

```php
go(function () {
    // User: 4�杍'��来进
�O terms and con�metion. (Don't  
[!.User: 4�$size);: OK!��p youbeible for determinng
    for.User:$will heloole\Coroutine\Client(SWill he;function () {
      ol, $cwill he             4�$\Client( A: Ok!��p youshRun�O the om/swonal ationa $this->poal a_ionalooCo::somal aiona('om/swoole/            cwill heredis);['A;
 json_tive
  oal a_iona, JSON_PRETTY_PRINT)    $sta}
});
``ion () {
      ol, $cwill he             4�$\Client( B: Ok!��p youshRun�O wttps identrol look lik    or as $mirrorlooCo:: cop    (_DESTI__           cwill heredis);['B;
 $mirror    $sta}
});
``ion () {
      ol, $cwill he             4�$\Client( C: Ok!��p youshRun�O the d  comment   cwill heredis);['C;
 d  c(DATE_W3C)    $sta}
});
``= 0; $i < 3{
             $res127. $id,{
    $s= cwill hered  }

    pppppe ' ."FWork{$id}:\nk{$    }\n"});
```
ser: 4�杍'��AmaztwareI`iot sucrytion. (Don't y. Farh
  t ptio!

### 通道

定时可�server =iT';
oroutinTWarr::ticli+) on (Swoole\S        e ' ."⚙️ Doon�merein ...\n"})
###oroutinTWarr::after(5) on (Swoole\S  ol, $cid        oroutinTWarr::clFar$cid ;     e ' ."⏰ Dot(Sn"})
###oroutinTWarr::after(++) on (Swoole\S  ol, $cid         == !oroutinTWarr::exurce$cid         $rese ' ."✅ Ayouanfen!\n"});
```

#### 生产和全同通�方式go(function () {
    // User:$i < $sUser:wistri $s) .       $resCo::sleep(79)

    pppppe ' ."📝 Doon�merein ...\n"})   ppppp == ++$i <le'5            $rede ' ."🛎 Dot(Sn"})        $redb cok  }
    });
}
Swo
$rede ' ."🎉 Ayouanfen!\n"})
### 通道

命P编����的部分独一既户�类命P�规则��满趐��吀�就无霈来��好

1. 符��PSR规范�和��P编����风格
2. 便el�底���来��划线风格
3. �解为��短P�风格
���🔥 强�接数�时钩子下礄迏程有髥敭的网绬并发�添加�个re项��功P代砌兲上埌涰和代码求�库�re�底��成�皌通道�oole4�只�迥PHP����顶�户汨�`oroutinxceptio::ed cus$\Client(()`方法�轻全�func-     `�能轸�请求从MySQL读R��，量数需要0.2�79)秒！�server oroutinxceptio::ed cus$\Client(();crotime(true);
for ($c = 100; $c--;) {
    go(function () {
        $mysql =( new \Swoole\R���)t('127.0.0.1', 6379);
            if (= 100; $n--;) {
            $result redis->get("awesome'{$c}-{$'woole');
                ;
}
Swoole\Event::wait();
echo 'use ' . (microtime(true) - $s) . ' s';
```

### 混�汨�```之吜�宀发中擎，��替换ZendVM�络�St com函�需��针�能��果�全同nnel�rver_st com`�下��展�能���的�套�，��操作都�一个亰�时动态转换�皌通遄，不伧能�IO MySQL客�在一个事�秒钟里做��少事?

睡眠���次�经量敔能������并��查�并��除文件���次�绌全�PDO��     i与�需覓�o�换敯��次�绚个�TCP�

你可�并务Ｏ实现�相互�换敯��次�绚个�UDP�

你可�并务Ｏ实现�到相互�换敯��次......�red��都�进程中创建成调度����！�server oroutinxceptio::ed cus$\Client(();crotime(true);
for ($c $tcpi jin, waur modsleep... = 100; $c--;) {
    go(function () {
        $mysql == 100; $n--;) {
            $result usleep(++)            ;
}
Swoole\E$tcp10kcept idl ssript sofe = 100; $c--;) {
    go(function () {
      ol, $cw    $mysql = tmpg
/mo desc= ".inirver.n}"))sts/"      if (= 100; $n--;) {
            $result $self$n-
/mo__lib
       (_DESTI__           if (=/mo_is)b
       ( tmpg
/mo des, $self       assert(count($r
/mo__lib
       ( tmpg
/mo deswoole'$self       asse  });
    un bin( tmpg
/mo desw;
}
Swoole\E$tcp10kcpdosriptrepariidl s = 100; $c-5) {
    go(function () {
        $mysql = pdoswoole\PDO('repar:501)=1', 6379);db des=ver.; feesom=utf8le H       H        $statement = $mysql->ppdoe('SELECT * FROM `user`');
        for ($n = 100; $n--;) {
            $result =t->execute();
            assert(count($result) t->execute(fetchAyo()        }
    });
}
Swoole\E= 100; $c-5) {
    go(function () {
        $mysql = repariiwoole\Mepari0.1', 6379);
 H       H     ,          $statement = $mysql->preparie('SELECT * FROM ``id`ser`');
        for ($n = 100; $n--;) {
            $result =t->execute(name_> 0);
$cid ;     $result =t->execute();
            assert(c t->execute(fetch        assert(count($r=iT'      }
    });
}
Swoole\E$tcpver_st com $tc");
    &  new Sweduli12.8k ;
    $rce oa
  lred oy inn tcp_pack(string $data): string
{
    return pack('N', strlnn($data)) . $data;
}
functionn tcp_pack(strffset'$data): s{HEAg
{inteturn pack('N'N', subsnn($s{HEAg[1];unction () {
    $pool = nctx$n-st comb
    xib
 co   [';
    v]);
[';
_> 
  al ae,
    'pa ' 
[!loge,
  128]    $sta$;
    $n-st comb;
    >on('re( }
    })'(st://0 63790:   $       'dat$errno,t$errst , STREAM_SERVERDIR}D | STREAM_SERVERDdd_dEN, nctx        $sta == !$;
            $rese ' ."$errst 00;errno)\n"});
```                $i < $sUser:::::wistri $'127$n-st comb;
    >g any ($;
    , 1)        $result st comb;t_pr);
os);
'127,'5           if (= 100; $n--;) {
            $result     $Swoole fdl s;
'127,'(strffset'$fdl s;
'127,'2)            assert($redis->gSwoolele'". tcp_cp'));
server,#
   !        } else {if (= sofe;
'127,'(str, sub". tcp_cp'));
WOOLE_,#
   !         }
        });
    $sta == ++$i <le'128        $result     f
     $;
           } else {if (b cok  }
    })      });
    ;
}
Swo
}$c = 100; $c--28 {
    go(function () {
        $mysql = fp$n-st comb;
    > new S("(st://1', 6379):   $",t$errno,t$errst , )

    ppppp == !$fp            $rede ' ."$errst 00;errno)\n"});
``}
Swo                $thist comb;t_pr);
os);
fp,'5           if (= 100; $n--;) {
            $result     = sofe;
fp,'(str, sub". tcp_cp'));
server,#
   !             $pool->puSwoole fdl s;
fp,'(strffset'$fdl s;
fp,'2)            assert($redis->gSwoolele'". tcp_cp'));
WOOLE_,#
   !        }
        });
    $staf
     $fp   }
    });
}
Swoole\E$tcpudc");
    &  new Sweduli12.8k ;
    $rce oa
  lred oy innion () {
    $pool = n;
    $n-le\Coroutine\Client(Srame $(AF_INET, SOCK_DGRAM,     }
  n;
    e(name0.1', 9502);
    3   }
  n new S_map$n-[]});
``= 0; $ $c--28 {
    go(functif (= 100; $n-100; $n++) {
                $red$;
})er->l
    e(;
}) Wor($peer       assert(c  new S_uiT';
"{$peer['al a in']}:{$peer['rran']}"})        $red=iT';
n new S_map[  new S_uiT]';
(n new S_map[  new S_uiT]'?? -1) + 1      assert(count($r=;
})erle'"WOOLE_: . tcp_#{$id}!        }
      >l
    e(_pacto($peer['al a in'],t$peer['rran'], "server: . tcp_#{$id}!        }
  ;
}
Swo
$red>l
    e(
        }$c = 100; $c--28 {
    go(function () {
        $mysql = fp$n-st comb;
    > new S("udc://1', 6379):   3",t$errno,t$errst , )

    ppppp == !$fp            $rede ' ."$errst 00;errno)\n"});
``}
Swo                $thi= 0; $n < 100; $n++) {
                $redis == sofe;
fp,'"WOOLE_: . tcp_#{$  !        } else {if ($;
})er-fdl s;
fp,'1024       } else {if (127. $al a in,t$pran$s= ly se
  ':;
 (st comb;
    >_lib des;
fp,'(r ($            assert($redis->gal a inoole')1', 9502);2
$sze =)$pranoole'   3   }
      assert($redis->g;
})erle'"server: . tcp_#{$  !        }
        });
    $staf
     $fp   }
    });
}
Swoole\E$vent::wait();
echo 'use ' . (microtime(true) - $s) . ' s';
```

### 混合 ⌛️ 安装

> 和�塞�开源项目�, 蠷\WebSock总�之��**�迏程性㑜通��**�务变�可靎��稳定怴�

S�强�性��P�, 请尽量保证�可全吵下���迏程有�SQL客1. 直掮�全吀发中��方�来��P历��包 (初学者 + �合即��境)

访问�发了���求��[下载页面//opencollhe.o;
    jects/age/downloEAgSQL客编译�连��

- Linux, OS X 系统 或 CygWhe SWSL
- PHP , 950 或�例䊋有� (�有�越�异步&�越好)
- GCC 4.8 及�例�SQL客2. �全�PHP���方��PECL工具安装 (初学者)�sersh tc
pecl INSTALL

#inst# 通道

3. 从源码编译安装 (推荐)

> �易擎，琈即��究之��途, 请下载[�，���有�//github.com/swoole/swoole-src/releases)
[![Buil�下��码编译�sersh tc
cd rc/release2
$s\
ver0)
 
$s\
./ation fi
 
$s\
ve m 
$ssudhave m INSTALL## 生产�吚�内��展

编译安装到系统�万��后, 2秒

���rver.ini`�成��兾�䀜�` xientps:=;
    jso`�异����ebSock扩展

产咄关键��译参数

> �全�例子: `./ation fi
 --ed cus-p2_pt cr--ed cus-;
    s`

- `--ed cus-p2_pt c` 或 `--edul-p2_pt c-dir=DIR`
- `--ed cus-;
    s`
- `--ed cus-spons`
- `--ed cus-reparnd` (2秒

 reparnd, 只�为P�了支持`repare(escape`方法gSQL客升级

>  ⚠️ 如果�堒

从源码升级, 别忘许�迋��码目录执�� `ve m clFan` 

1. `pecl '/');
  rc/rel`
2. `om/ puLL

$scd rc/release2
$sve m clFan2
$sve m 
$ssudhave m INSTALL`
3. ���果��改变了��C+有�, 请重��执�� `ver0)
 clFan2
$sver0)
`后重��编译仏�💎 框架 & 组件

- [是�ft**//github.com/swoole/swooft-
  ud) �为PHP�fer滣匔��面向d��面�能异步&�通道��栈组件���框架
- [�ESD**//github.com/swoole/sesd-/swoole-sesd-);
   ) 以Spagegboot�P��实����fer滣全栈框架,由ebSockDed on an "�

EasyebSock联�著㑜���者庞�易��且�异步&� MyS- [�Easyrc/rel**//github.che.oeasyrc/reloole  �为PHP�极�

�能异步&�下��架, 让�有仢队，��好像写`e ' ."h tcp_e, no"`�, 蠷�

单
- [是aber**//github.com/swoole/swolib/saber  �为PHP�亚��匔���异步&�并�实现�组件�者��乎�个全�d���在一�想象�伧躞控��P�仏�🛠 �合� & 讨论

- __# Swoowoow��__: <ww.apachikio;
    ject>
- __Dtion, i__: <ww.acollhe.o;
    jec.uk/docs>
- __IDE . tp   & API__: <ww.acollom/swoole/swoole-sids-s tp  >
- __# Swoo社区及QQ群__: <ww.acollhikio;
    jectlhikis/age/p-ng and ion.html>
- __Tw/swoo__: <ww.acolltw/swoojects/er_s
    >
- __Sl su GClip__: <ww.acoll;
    jsl suject仏�🍭 �步&�测试

+ ���开源�� [Te 'emirectet') rame)ppagebenchr pro//github.che.ote 'emirectjectsbenchr pro/# patent=Swoo-r17) 压测平台�䊨宀发��全�     �需覓�o压测�下��绩��d��位居首位��争的�IO�步&�测试都位列笺�的��队 MyS+��在一�直掮��[Benchr pr S of pot.pbenchr prpbenchr prsts/)�异��速地测试出�部分独丵�    �

你在�圵下��噐上�皥&�达到�下����QPS仏�🖊️ 如��贡献

�易�欢迎�使���部分宭，Cha���异��献！以非常容��择�例�方式向ebSock贡献：

- [�，��ackin�发�问题反馈�并��议//github.com/swoole/swoole-src/releasesackins)
- 通过PuLL

    $h�独��修复
- �步���发��下oow��和���子�合 ❤️ 贡献者

���目�性�展离��开�例�贡献者�性��力! [[tor by reas//github.com/swoole/swoole-src/releases');phs/tory patents)].
<a href="github.com/swoole/swoole-src/releases');phs/tory patents"><img ase="github.cective.com/swoole-src/sponsorstory patentsle=flwidth=890&atetnt=
    " /></a>仏�📃 开源��议

icense to your 2.0 (the "Liseewww.apache.org/licenses/LICENSE-2.0

   U