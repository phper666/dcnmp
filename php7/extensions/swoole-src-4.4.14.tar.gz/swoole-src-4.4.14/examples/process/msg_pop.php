<?php
use Swoole\Process\Pool;

$pool = new Pool(1, SWOOLE_IPC_MSGQUEUE, 0x9501);





4
mProagceive', functinew  1);

('N',ing_id, $data) {
();
var_du . $data9501);



rv->start();
