/*
 * librdkafka - Apache Kafka C library
 *
 * Copyright (c) 2014, Magnus Edenhill
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met: 
 * 
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution. 
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * Apache Kafka consumer & producer example programs
 * using the Kafka driver from librdkafka
 * (https://github.com/edenhill/librdkafka)
 */

#include <iostream>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <csignal>
#include <cstring>

#ifdef _WIN32
#include "../win32/wingetopt.h"
#elif _AIX
#include <unistd.h>
#else
#include <getopt.h>
#endif

/*
 * Typically include path in a real application would be
 * #include <librdkafka/rdkafkacpp.h>
 */
#include "rdkafkacpp.h"


static void metadata_print (const std::string &topic,
                            const RdKafka::Metadata *metadata) {
  std::cout << "Metadata for " << (topic.empty() ? "" : "all topics")
           << "(from broker "  << metadata->orig_broker_id()
           << ":" << metadata->orig_broker_name() << std::endl;

  /* Iterate brokers */
  std::cout << " " << metadata->brokers()->size() << " brokers:" << std::endl;
  RdKafka::Metadata::BrokerMetadataIterator ib;
  for (ib = metadata->brokers()->begin();
       ib != metadata->brokers()->end();
       ++ib) {
    std::cout << "  broker " << (*ib)->id() << " at "
              << (*ib)->host() << ":" << (*ib)->port() << std::endl;
  }
  /* Iterate topics */
  std::cout << metadata->topics()->size() << " topics:" << std::endl;
  RdKafka::Metadata::TopicMetadataIterator it;
  for (it = metadata->topics()->begin();
       it != metadata->topics()->end();
       ++it) {
    std::cout << "  topic \""<< (*it)->topic() << "\" with "
              << (*it)->partitions()->size() << " partitions:";

    if ((*it)->err() != RdKafka::ERR_NO_ERROR) {
      std::cout << " " << err2str((*it)->err());
      if ((*it)->err() == RdKafka::ERR_LEADER_NOT_AVAILABLE)
        std::cout << " (try again)";
    }
    std::cout << std::endl;

    /* Iterate topic's partitions */
    RdKafka::TopicMetadata::PartitionMetadataIterator ip;
    for (ip = (*it)->partitions()->begin();
         ip != (*it)->partitions()->end();
         ++ip) {
      std::cout << "    partition " << (*ip)->id()
                << ", leader " << (*ip)->leader()
                << ", replicas: ";

      /* Iterate partition's replicas */
      RdKafka::PartitionMetadata::ReplicasIterator ir;
      for (ir = (*ip)->replicas()->begin();
           ir != (*ip)->replicas()->end();
           ++ir) {
        std::cout << (ir == (*ip)->replicas()->begin() ? "":",") << *ir;
      }

      /* Iterate partition's ISRs */
      std::cout << ", isrs: ";ka::PartitionMetadata::ReplicasItercaso/* On */
  asItercaso/    	-tIMPL*/
    RdKafka::TopicMetadata::Partigkafka/ri(int aTopicMetadata::rrr = RD_TopicMpicMetat        if Enable debu) << " partitions:";

    rr() == RdKafka::ERR_LE,< (*ip " partitERR_NO_ERROable debutition() << "] at offs* Now owned b   std::cout << " (try a->repl    priude "rdkafka.h"  /* for Kafka driver */


staboolrun = 1;
stafhe eMP,
	OUTPUT_RAW,ig

	/      }
     _destroy(me;

	s lss E
/**
 Dka_pollRk, 0)Cb <<pub) {p " partitDka_pollRk, 0)Cb   _pub) {UT_RT_RAWdr_cb (s()->size()consum&_consume(= metadata-


stat
	OUus_ = 0;
    , "PCLt:_kafka_p
	OUusbutw owned*ip)->re     s()->size()consuze(SG_STATUS   ifPSOFISEQU:w owned b  OUus_ = 0) {
NotP[0],sted"
          run = 0;
        s()->size()consuze(SG_STATUS  THIS LYfPSOFISEQU:w owned b  OUus_ = 0) {
PossiblyP[0],sted"
          run = 0;
        s()->size()consuze(SG_STATUS  SOFISEQU:w owned b  OUus_ = 0) {
P[0],sted"
          run = 0;
   rrstr);
	 owned b  OUus_ = 0) {
				res?"
          run = 0;
   
        std::cout tput == Oderr,
    ata:
  /* Iafka_pn);
:cout <<if (na< (*i
wned b  OUus_ = 0) << " 
  /* Iafka_pessage-tition() << "] at of/
		rIafka_pkeybutw owned   std::cout ty, rk
  /**	rIafka_pkeybutout t;<< metadata->topic  p;

	s lss E
/**
 Even)Cb <<pub) {p " partitEven)Cb   _pub) {UT_RT_RAWeven)_cb (s()->sizeEven) &even)e(= metad "PCLt:even).				butw own*ip)->re     s()->sizeEven)zeEICUL;

   
	 owned b&metaven).f ",l(                  stdimpout tFATAL "
           estroy(metadata);}
           stdimpout t

   a:
  /* " partitERR_NO_Eaven). debutitio"na< (*i
wned bbbbbbbaven).age-tition() << "] at of     run = ip)->re     s()->sizeEven)zeEICUL;STATS:
           stdimpout t\"STATS\ " 
  /*aven).age-tition() << "] at of     run = ip)->re     s()->sizeEven)zeEICUL;LOG:
        kafka_brokers_addLOG, NULL);
	        "%% Failed toaven).aaveristd:, aven).f    .c"
			"\naven).age-t.c"
			") at of     run = ip)->rerrstr);
	 owned b   stdimpout t
ICULA
  /*aven).				bu(*i
wned bbbbbbb"a:
  /* " partitERR_NO_Eaven). debutitio"na< (*i
wned bbbbbbbaven).age-tition() << "] at of     run = ta);}
    p;

	>beU   ;
spath w
			"  -p  th woetty poka_lonersi repno     i documentae <li condi        )     und ts lss MyHashP
			"  -p Cb <<pub) {p " partitP
			"  -p Cb   _pub) {UT_R*metadatw
			"  -p _cb (tring &topic,
 T       

    kafkacpp.h"


stat*ump( metadata_print (const std:*metadatw
			"  -           c                  (run <=djb_hash(ump->c"
			"\nump->h "
  ) %tw
			"  -    ost() <afkv) ?:

 b  OUkafkaline unde <     t=djb_hash->payload);
}
s(FILE *fp, const c    unde <     t=hash-= 5381opicMetadatessage, conf,
					or (i = of metadahash-= ((hash-tio5) +ahash) +a_kaffka_meta(run <=hashopic  p;

st char *)rkmess(s()->size()consu*back.
		 *st c*             tring &topic,
         *       = ip), "PCLt:_kafka_le debuti c         s()->sizeE     (tsD_OUT
	 owned run = ip)->     s()->sizeE   :";

   
	 ownedue;

alsg_consum     }

      /* Iterat

achar  %s [%"PRId
  /* Iafka_2"):\n",-tition() << "] at of  /
		rIafka_(int)(                std::cout ty, rk
  /**rIafka_(int)( ition() << "] at of  }
             adataafka_(i	}

      std::cout <	}

                  stvec::P<&topic,
        
       >if (!hdr	}

   ->        ) at of    tadatessage, conf,
					f (!.h "
        for (i = 0 ; itring &topic,
        
       	f (hdr	drkafka_ (i = 0 ; i    exi.			" bu) <<
				 metadata_prit->partit      ic)) =                 "%% Failed to acexi.nt)( .c"
			"\    "%% Failed to ac		   exi.			" _h "
                  exi.			" bu;
           * Now owned by tot->partit      icc)) = 
			AFKA_exi.nt)( .c"
			")metadata);}
      }
      essage->payload,           OUka_   t<sag>	rIafka_(in);
:),           OUka_   t<            >	rIafka_(i    Be 
:))metadata run = ip)->     s()->sizeE   		if (rkmessag
	 ownedue;L			"  -e   m     }

 ssage->partitor (i = 0 ;estroy(metadata}etadata run = ip)->     s()->sizeE   	     rkmessag:ip)->     s()->sizeE   	     rkm	if (rkme:   }

      /impout t        intf(stde  /* Iafka_2"essage-tition() << "] at of ;estroy(metadata run = ip)->rrstr);
	 ownednf_dge;

m     }

      /impout t        intf(stde  /* Iafka_2"essage-tition() << "] at of ;estroy(meta}e;

	s lss E
/**
        Cb <<pub) {p " partit       Cb   _pub) {UT_RT_RAW }
		}

cb (s()->size()consum&_sg       const rd_kafka_ar *)rkmess(&_sg  onst rdopic  p;

	(int sig) {
	rd_kafka_dump(stdout, rtadata-


stat **argv) {
	rd_kafka"
   data-


statessage
   data-


stat      age
   data-


statrd_k
   data-


statrecei;T_R*metadatw
			"  - = &topic,
 T    itP*topic = NULLnt do_conf_ == 'o')
     &topic,
 T    it, "beginning"))
		 aboolr	}

			if (!strfhe eMPruct r 'C':  MyHashP
			"  -p Cb hash_w
			"  -p MPruct rus

ccbucer
		ednfafkaed\n");
	rop=name>  Setith \"           " partit   fA_PART   &topic,
    f  /n");
(&topic,
    f   sizeGLOBAL);    " partit   fA_tPART   &topic,
    f  /n");
(&topic,
    f   sizeessage   rd_topic_conf = rd_kafka_topic_conf_new();

	while ((opt M:fetopt(argc, ar}

   "PCLt:p:b:z:qp)->     As:H:p)->     AC:H:p)->     ALPUT_RAW;

		case 'C':tadata run = p)->     AtPUT_RAW;
      ageame_sz = -1;

    run = p)->     ApPUT_RAW;
rties_show(stdout);
	oduce\")	 metadata/*>rrstr);    at offs* No
rties_show(stdout);
	hash"              rd_kPART->h",-"w
			"  -p _cb"ffseash_w
			"  -p A_CONF_OKopta            &topic,
    f   sizeof(err               /impout CONF_Oition() << "] at of    2str(err));
       }
      } * Now owned bw
			"  - = n() <arg;
			break;;

    run = p)->     Ab'
	 owned r atoi(optarg);
	;

    run = p)->     AzPUT_RAW;
rtiePART->h",-"case 'z':
			if (rd':
			if_CONF_OKopta	  &topic,
    f   sizeof(err	     /impout CONF_Oition() << "] a	tr(err));
     }	;

    run = p)->     AoPUT_RAW;
rties_show(stdout);
	        _ == 'o')
     &topic,
 T    it, "begi "endt offs* No
rties_show(stdout);
	_OFFSET_END;
	_ == 'o')
     &topic,
 T    it, "beginning"))
		 aoffs* No
rties_show(stdout);
	T_BEGINNING_ == 'o')
     &topic,
 T    it, "begitored")) aoffs* NoNG_ == 'o')
     et_wmarks = 1;
			else {
		;

    run = p)->     AePUT_RAW;
un = 1;
staa_co		;

    run = p)->     AdPUT_RAW;
recei(optarg);
	;

    run = p)->     AMPUT_RAW;
rtiePART->h",-"  OUksUkas., "%i			.msrd':
			if_CONF_OKopta          &topic,
    f   sizeof(err             /impout CONF_Oition() << "] at of    tr(err));
     }	;

    run = p)->     AXPUT_RAW;
{
                bre
erties_show(stdout);
				exit(0); r	}

			if (!stra_co			ta->brorts */    	do_conf_dump = 
				continue;
			}

			name = opt               /impout t%% E
p \"   -Xration\n"r)\n"
,ry f< (*i
wned bbbbbbbze_t nation() << "] a	  tr(err));/     "Invalid");
			exit(1)al++;

			res = RD_KAFKA_CONF_UNKNOWN;
			/* T "topic." prefixed properties on topic
			 * conf fst, and then fall through to global if
			 * it didnt        &topic,
    f     fResr); 	charatch a topic configuration property. */
			if (!s bbbbbbbze
			ifkPART->h",-a_topic_conf_get(
				= rd_kFailed tot of    t NoNGze
			ifPART->h",-a_to	= rd_kFailed to
, val,
						topic,
    f   sizeof(err               /impout CONF_Oition() << "] a	  tr(err));/  
     }	;

    run = 	;

        Af'
	 owned b&mets_show(stdout);
	ccb"(!s bbbbbbbzeus

ccbuce1tot of    t Noopt               /impout t				resation, tde  /*tdout)ition() << "] at of    2str(err));
       }
      ta run = ip)->rrstr);
	 ownedexit(1);
			    }
  plica/
		rd_k{
  std::
		}      age{
  std::&& == 'C' &"Lf_res free(arr, cnt)(err  nd != ar  data-


statf");u	chara fPART->KA_C"builee(.f");u	chprof");u	ch));
   _ERROR) {
                  & !topic)) [{
	us]:
		fprintf(st            &,
			"Usage: %s -C|-P|-L -t <topic> "
			"[-p <partiti            &titi            &st1:port1,host2:port2,..>]\n", builee(.f");u	chtopics[              Raw&titi            &dkafka versio            &d(0x%08x)\n"
			"\n"
			" Options:\n"
			"  -C | -P         Producer mode\n"
                       | -P         Pro             Metadata list mode\n"
			"  -t| -P         Pro>      Topic to fetch / produce\n"
			"  -p <num>| -P         Pro>  fun      MeeU   "
			"  -p ersio            &d(((((((((((((((((oduce\n(rrstr);		=eashnum>| -P         Pro Partition (random partitioner)\n"
			"  -b <broke| -P         ProBroker address (localhost:9092)\n"
			            &d(((((((((((((((((ble compression:\n"
			"     | -P         Pro      none|gzip|snappy|lz4|zstd\n"
			    | -P         Procurrent hi&lo "
			"watermarks.\n"
			"  -e                   &d(((((((((((((((((hen last message\n"
			"           | -P         Proin partition has been received.\n"
			"  -d [            &d(((((((((((((((((ugging| -P         ProM <, "%i			mn (s been   OUksUkasging| -P         Prodd header to message (producer)\n"
			"  -| -P         rop=name>  Set arbitrary l            &d(((((((((((((((((uration property\n"
			"                          &Properties prefixed with \"topic            &d(((((((((((((((((U   '			"wil'f(stdedistripic objecopic            &d(((((((((((((((((.\n"
			"  -X        Show fu| -P         Prof  flag     Meessagtion, topic            &d((((((((((((((((((((ccbu-right }
		}

c                    Raw&titi            &dGet single property v            &d("
			"\n"
			" In Consumer mode:\n"
	            &dGettes fetched messag            &d(stdout\n"
			" In Producer mode:\n"
			"  reads messages from&titi            &titi            &tit,((mode optional.mode	topic,
 
			"\n"
			".c"
			"\n	topic,
 
			"\n		rd_kf");u	ch.c"
			"\ .mode	topic,
     recei_n"
			" ( .c"
			")me	tr(err));
 }
		ednfafkaedssagrop=name>  Set arbitr Sh         PART->h",-"metadata. to bro_confd brokers_kFailed to
 b&metsrecei{
  std:(err    rtiePART->h",-"case 'd'case f_CONF_OKopt		topic,
    f   sizeof(err           /impout CONF_Oition() << "] at of  tr(err));
   }
  plicaE
/**
 Even)Cb ex_even)_cb;   PART->h",-"even)_cb"ffsex_even)_cb_kFailed to
 b&met

		default:
			    rp) {
		con     char **arr;
		size_t cnt;
		int pass           _con<data-


sta> *ult: std::cout < ; pass < 2 ;        f (!strPART->commi));
          std::cout t_kafka_conf_dum<< metadata->topic
   } t Noopt        f (!straPART->commi));
          std::cout t_kbal config\n<< metadata->topic
   } 	;

   tadate    _con<data-


sta>::i:endl;
  Rstrcommator ir;
      for (ir it = commatin();
                std::cout *i()->end= "
         ifka_t           std::cout *i()->en() << "] at of    ifka_t      }
         std::cout << " (try a->repl    tr(er0));
 }
	    isatty(STDOUT_ig

	/));
   isatty(STERMUT_ig

	/));lica/
		rd_kass "P"        nfafka 1, sig_usr1hed mafka 1,/)->parti}      age{
  std:!s bbbbbexit(1);
			s bbbE
/**
 Dka_pollRk, 0)Cb ex_dr_cb again)";
ssag                         dnt    PART->h",-"cr_cb"ffsex_cr_cb_kFailed to
 b  PART->h",-"crstr);  if (topiconf_
		 */Failed to
 b  nfafka 1, \n");
	MAGE.
 */a consaccumula  -Xgfka_conf_dumme>  Se.afka 1,/)ka 1 " partitPAGE.
 */*MAGE.
 */=1 " partitPAGE.
 *  /n");
(
		 */Failed to::cout <! -H <nameerr           /impout "f(errstr)))) {
		intf(stder"out CONF_Oition() << "] at of  tr(err));
   }

       std::cout t% \n");
d	MAGE.
 */"out MAGE.
 *->          << ":" << me
 b  nfafka 1, 

achan"
			" In Producer mod            to broafka 1,/)ka 1tadate    


statline;  for mee       linete    ci - %ine);eerr      ut <%ine{
  std:(err        MAGE.
 *->rk) >age =->brorts *ic
   } 	;

   &topic,
         *       /=1 " partit       
 /n");
(
      fo	}

   ->	/* "myo	}

  "p(opt    	)\n"
"
      fo	}

   ->	/* "claime	}

  "p(oychp)leader()
  r       , sig_usrhan"
			r       ,;

      /* Iteradge;
Cd_ka_hea =r        MAGE.
 *->r             age                                        " partitPAGE.
 *  RK     
 * fied\y;

    Be q*/                            iedVze =                             *     _   t<      >	%ine{c"
			")- %ine.h "
                              iedKey                             *                                   al++ian"t/**n(rrstr);"
			now)                             *                             al+()consum	}

   , ut any                             *	}

   ,                           al+P *-  -e   monst rsize =  ; prstr)                                                                          *      std::cout <_hea  << " partitions:";

    if ((*it)       /impout t% sig_usrhintf(stde  /            " partitERR_NO_E_heatition() << "] at of       etum	}

   
            ed pauto    lse
#i   etuery i        )                          *be calledidnt      } t Noopt             /impout t% sig_usrchan"
			a:
  /*%ine.h "
  cout <<if (ne  /           tadata->topic
   } 	;

   MAGE.
 *->rk) >age 
   } 
    driver * 
   /* Wait for meMAGE.
 *->tition);
      err           /impout "fka_wait_des"out MAGE.
 *->tition);
  tion() << "] at of  MAGE.
 *->rk) >1          } ip)->rr etumMAGE.
 * me
 bandle */
		rd_kafka"C"        nfafka 1,  single propeafka 1,/)->parPART->h",-"e                rd_kafka_conf/Failed to
 b  ti}      age{
  std:!s bbbbbexit(1);
			s bbbnfafka 1, \n");
	watermarka consaccumula  -Xgfka_conf_dumme>  Se.afka 1,/)ka 1 " partit single p*watermark=1 " partit single   /n");
(
		 */Failed to::cout <!td\n"
			err           /impout "f(errstr)))) {
		intf(stder"out CONF_Oition() << "] at of  tr(err));
   }

       std::cout t% \n");
d	watermark"out watermar->          << ":" << me bbbnfafka 1, \n");
	ixed wfka_to.afka 1,/)ka 1 " partitT       

     &topic,
 T    it/n");
(
		ermar,
      age	arr = ra 1_
		 */Failed to::cout <!   /* Create to     /impout "f(errstr)))) {
		   /*er"out CONF_Oition() << "] at of  tr(err));
   }

    nfafka 1, nf = NULL; /n"
       /*+ last messanf_ == py|lz4|afka 1,/)ka 1 " partitdge;
Cd_ka_hea = watermar->Start      "%"PRId64" - f (rd_kafka_cto::cout <_hea  << " partitions:";

    if ((*it)     /impout "f(errstr))sf = NULL; /n"tde  / 	 " partitERR_NO_E_heatition() << "] at of  tr(err));
   }

    E
/**
        Cb ex_ }
		}

cb me bbbnfafka 1, \       an"
			"afka 1,/)ka 1             rkt = Nut <us

ccb if ((*it)  watermar-> }
		}

c             "%"PRId64" - 1        "%% Failed to acquire metadata: &ex_ }
		}

cbffsus

ccb opic
   } t Noopt        s()->size()consumc    = watermar->)rkmess(     "%"PRId64" - 1   
      for ar *)rkmess(_sg        std::co->rr etum_sg_t      }
      watermar->rk) >age 
   } 
    nfafka 1, nf 0;
     erafka 1,/)ka 1watermar->Stop(     "%"PRId64"  to
 b  PARermar->rk) >1   
  ip)->rr etum     ;ip)->rr etumPARermar;
  } t Noopt    al+()       rd_ka,/)->parnfafka 1, \n");
	MAGE.
 */a consaccumula  -Xgfka_conf_dumme>  Se.afka 1,/)ka 1 " partitPAGE.
 */*MAGE.
 */=1 " partitPAGE.
 *  /n");
(
		 */Failed to::cout <! -H <nameerr           /impout "f(errstr)))) {
		intf(stder"out CONF_Oition() << "] at of  tr(err));
   } 
       std::cout t% \n");
d	MAGE.
 */"out MAGE.
 *->          << ":" << me>parnfafka 1, \n");
	ixed wfka_to.afka 1,/)ka 1 " partitT       

          }::cout<!   /* age{
  std:!err       

     &topic,
 T    it/n");
(MAGE.
 *,
      age	1_
		 */Failed to::cocout <!   /* Create toto     /impout "f(errstr)))) {
		   /*er"out CONF_Oition() << "] at of    tr(err));
     }	;

 }* 
   /* Wait fo Create tos lss &topic,
                   leader()
   ta *metadata;

          " partitdge;
Cd_kaFetch MAGE.
 *->*/
      !                 "%% Failed to acquire metad                        &metadata, 5" partitions:";

    if ((*it)       /impout t%                                                   /* " partitERR_NO_Ea    tion() << "] at of    2sssssestroy(metadata);
      run = 0;
   
  0;
                  }

   age	1                  rr etum_       le2sssssestroy(metada
  0;
  0;rr etumPARf; 0;rr etumtPARf; 
ednfafkaed reports  " part0) == -1)
		prin.afkaedTath th y f<


sct
#ineentat(s.\n"check tition);
  butio), butafkaeda,
 *s  " part0) =(topic_conll     _hes aree\n"rtsdistrib

/*
 * Tyafkaedtr(es sout
 * memo   MAGf   0) {ull tssizegre(arw);

ost:lig) bututafkaedmemo   topks.afkae     " partit/
	run = 5;
	wh5   
  ip)(run <= 0)
		rd_kafka_dump(stdout, rk);

	return 0;
}
